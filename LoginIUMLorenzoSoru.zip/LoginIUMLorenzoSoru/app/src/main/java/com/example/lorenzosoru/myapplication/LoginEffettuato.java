package com.example.lorenzosoru.myapplication;

public class LoginEffettuato {
}
