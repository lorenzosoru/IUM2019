package com.example.lorenzosoru.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;


public class Login extends AppCompatActivity implements OnClickListener{
    private Button buttonIndietro;


    @Override
    protected void onCreate(Bundle savedIstanceState){

        super.onCreate(savedIstanceState);
        setContentView(R.layout.activity_in);

        final String USERNAME="1";
        final String PASSWORD="1";
        Intent intent = getIntent();

        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");
        TextView textViewUsername = (TextView)  findViewById(R.id.testo);

        if(username.equals(USERNAME) && password.equals(PASSWORD)){


            textViewUsername.setText("Benvenuto "+ username);

        }else {
            textViewUsername.setText("Nome utente errato");
        }


    }

    @Override
    public void onClick(View v){
        buttonIndietro = (Button) findViewById(R.id.login);

        buttonIndietro.setOnClickListener(this);
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);


        }
    }

