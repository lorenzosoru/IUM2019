package com.example.lorenzosoru.myapplication;

public class LoginErrato {
}
