package com.example.lorenzosoru.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    private final String USERNAME="1";
    private final String PASSWORD="1";
    private EditText editTextUsername;
    private EditText edistTextPassword;
    private Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Istanze degli oggetti del layout
        editTextUsername = (EditText) findViewById(R.id.user);
        edistTextPassword = (EditText) findViewById(R.id.pass);
        buttonLogin = (Button) findViewById(R.id.login);

        buttonLogin.setOnClickListener(this);




    }

    @Override
    public void onClick(View v){

        String username = editTextUsername.getText().toString();
        String password = edistTextPassword.getText().toString();

        if(username.isEmpty() || password.isEmpty()){

            Toast.makeText(this,"Inserire campo vuoto",Toast.LENGTH_SHORT).show();

        } else {


            Intent intent = new Intent(MainActivity.this,Login.class);
            intent.putExtra("username",username);
            intent.putExtra("password",password);
            startActivity(intent);

        }
    }
}
